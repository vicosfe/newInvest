<?php


namespace App\Http\Controllers;

use App;
use App\Menu;
use Illuminate\Http\Request;

class MenuController extends Controller
{



}
