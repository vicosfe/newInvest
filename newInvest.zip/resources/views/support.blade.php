@extends('uniquepage')
@section('main')
	<div class="uniqueDescription">
				<p>Создание и обеспечение функционирования специализированного раздела об инвестиционной деятельности города Махачкалы на официальном сайте Администрации города. Создание и обеспечение функционирования специализированного раздела об инвестиционной деятельности города Махачкалы на официальном сайте Администрации города.</p>
			</div>
<div class="supportMain">
	
	<div class="supportMain__item">
		<a href="#">
			<div class="wrapSup">
				<div class="supportMain__item--text">
					Центр поддержки предпринимательства Республики Дагестан
				</div>
			</div>
		</a>
	</div>

	<div class="supportMain__item">
		<a href="#">
			<div class="wrapSup supMsub supMclose">
				<div class="supportMain__item--text">
					Центр поддержки предпринимательства Республики Дагестан
				</div>
			</div>
		</a>
		
		
		<div class="supportMain__item--sub">
			<a href="#">
				<p>Республиканский офисный бизнес-инкубатор</p>
				<div class="itemSubRight">
					<img src="/public/images/linkFile.png" alt="">
					<p>Скачать</p>
				</div>
			</a>
			<div class="subDescription">
				<p>
					Создание и обеспечение функционирования специализированного раздела об инвестиционной деятельности города Махачкалы на официальном сайте Администрации города.
				</p>
			</div>			
		</div>
	</div>

		<div class="supportMain__item">
		<a href="#">
			<div class="wrapSup supMsub supMclose">
				<div class="supportMain__item--text">
					Центр поддержки предпринимательства Республики Дагестан
				</div>
			</div>
		</a>
		
		
		<div class="supportMain__item--sub">
			<a href="#">
				<p>Республиканский офисный бизнес-инкубатор</p>
				<div class="itemSubRight">
					<img src="/public/images/linkFile.png" alt="">
					<p>Скачать</p>
				</div>
			</a>
			<div class="subDescription">
				<p>
					Создание и обеспечение функционирования специализированного раздела об инвестиционной деятельности города Махачкалы на официальном сайте Администрации города.
				</p>
			</div>			
		</div>
	</div>

		<div class="supportMain__item">
		<a href="#">
			<div class="wrapSup supMsub supMclose">
				<div class="supportMain__item--text">
					Центр поддержки предпринимательства Республики Дагестан
				</div>
			</div>
		</a>
		
		
		<div class="supportMain__item--sub">
			<a href="#">
				<p>Республиканский офисный бизнес-инкубатор</p>
				<div class="itemSubRight">
					<img src="/public/images/linkFile.png" alt="">
					<p>Скачать</p>
				</div>
			</a>
			<div class="subDescription">
				<p>
					Создание и обеспечение функционирования специализированного раздела об инвестиционной деятельности города Махачкалы на официальном сайте Администрации города.
				</p>
			</div>			
		</div>
	</div>

		<div class="supportMain__item">
		<a href="#">
			<div class="wrapSup supMsub supMclose">
				<div class="supportMain__item--text">
					Центр поддержки предпринимательства Республики Дагестан
				</div>
			</div>
		</a>
		
		
		<div class="supportMain__item--sub">
			<a href="#">
				<p>Республиканский офисный бизнес-инкубатор</p>
				<div class="itemSubRight">
					<img src="/public/images/linkFile.png" alt="">
					<p>Скачать</p>
				</div>
			</a>
			<div class="subDescription">
				<p>
					Создание и обеспечение функционирования специализированного раздела об инвестиционной деятельности города Махачкалы на официальном сайте Администрации города.
				</p>
			</div>			
		</div>
	</div>

		<div class="supportMain__item">
		<a href="#">
			<div class="wrapSup supMsub supMclose">
				<div class="supportMain__item--text">
					Центр поддержки предпринимательства Республики Дагестан
				</div>
			</div>
		</a>
		
		
		<div class="supportMain__item--sub">
			<a href="#">
				<p>Республиканский офисный бизнес-инкубатор</p>
				<div class="itemSubRight">
					<img src="/public/images/linkFile.png" alt="">
					<p>Скачать</p>
				</div>
			</a>
			<div class="subDescription">
				<p>
					Создание и обеспечение функционирования специализированного раздела об инвестиционной деятельности города Махачкалы на официальном сайте Администрации города.
				</p>
			</div>			
		</div>
	</div>

		<div class="supportMain__item">
		<a href="#">
			<div class="wrapSup supMsub supMclose">
				<div class="supportMain__item--text">
					Центр поддержки предпринимательства Республики Дагестан
				</div>
			</div>
		</a>
		
		
		<div class="supportMain__item--sub">
			<a href="#">
				<p>Республиканский офисный бизнес-инкубатор</p>
				<div class="itemSubRight">
					<img src="/public/images/linkFile.png" alt="">
					<p>Скачать</p>
				</div>
			</a>
			<div class="subDescription">
				<p>
					Создание и обеспечение функционирования специализированного раздела об инвестиционной деятельности города Махачкалы на официальном сайте Администрации города.
				</p>
			</div>			
		</div>
	</div>




</div>

	@stop