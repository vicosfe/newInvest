<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;

class Mail extends Model
{
    public $timestamps = false;

}
