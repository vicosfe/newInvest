<?php
return [

    'heading_useful_links' => 'Полезные ссылки',
    'president_site' => 'Президент РФ',
    'goverment_site' => 'Правительство РФ',
    'goverment_rd_site' => 'Правительство РД',
    'makhachkala_news' => 'Махачкалинские известия', 
    'fscn_site' => 'ФСКН',
    'skfo_site' => 'СКФО.ru',
    'russian_public_initiative' => 'Российская общественная инициатива',
    'public_oversight' => 'Общественный надзор',
    'makhachkala_mfc' => 'Махачкалинский МФЦ',
    'main_portal' => 'Главный интернет портал регионов России',
    'state_portal' => 'Портал гос./муниц. учреждений',
    'tourism_center' => 'Городской центр туризма',
    'business_support' => 'Портал поддержки предпринимательства',
    'site_ogv_omsu' => 'Единый сайт ОГВ и ОМСУ',
    'ocenka_regular_vozdeistviya' => 'Оценка регулирующего воздействия',
    'input_search' => 'Некоммерческий фонд кап. ремонта имущества МКД',
    'btn_find' => 'Портал "Работа в России"',
    'btn_feedback' => 'Прокуратура РД', 
    'btn_hotline' => 'Банк исполнительных производств',
    'btn_download' => 'Уполномоченный по защите прав предпринимателей',
    'btn_load_more' => 'Портал гос. услуг',
    'btn_load_more' => 'Портал госзакупки'

];