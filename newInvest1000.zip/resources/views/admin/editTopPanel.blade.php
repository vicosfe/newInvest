	<section>
		<div class="editDescription">
			<div class="editDescription__img">
				<div class="editDescription__img--block"></div>	
			</div>
			<div class="editDescription__text">
				<h3>Редактирование контента</h3>
				<p>здесь вы можете редактировать информацию во всех разделах сайта.</p>
			</div>
		</div>	
	</section>