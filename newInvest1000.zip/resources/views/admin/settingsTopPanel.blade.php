	<section>
		<div class="settingsDescription">
			<div class="settingsDescription__img">
				<div class="settingsDescription__img--block"></div>	
			</div>
			<div class="settingsDescription__text">
				<h3>Настройки контента</h3>
				<p>здесь вы можете настроить разделы сайта.</p>
			</div>
		</div>	
	</section>