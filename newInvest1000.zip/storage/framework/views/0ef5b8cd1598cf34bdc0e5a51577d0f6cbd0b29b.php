<?php $__env->startSection('main'); ?>
<section>
	<div class="articleCaption">
		<h3><?php echo e($item->title); ?></h3>
		<?php if(count($media)): ?><div class="media" style="height: 432px;"><?php echo $__env->make('mediaSlide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div><?php endif; ?>
		<div>
			<p></p>
			<?php echo $item->description; ?>

			<p></p>
		</div>
		<?php if(count($docs)): ?>
		<div class="articleDoc">
			<?php $__currentLoopData = $docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="articleDoc__item">

					<div class="articleDoc__item--text"><a target="_blank" href="https://view.officeapps.live.com/op/view.aspx?src=http%3A%2F%2Finvest-mah.tmweb.ru<?php echo e($doc->link); ?>"><?php echo e($doc->title); ?></a></div>
					<div class="articleDoc__item--img">
						<img src="../public/images/linkFile.png" alt="">
						<p><a href="<?php echo e($doc->link); ?>">Скачать</a></p>
					</div>

			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
		<?php endif; ?>
	</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('uniquepage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>