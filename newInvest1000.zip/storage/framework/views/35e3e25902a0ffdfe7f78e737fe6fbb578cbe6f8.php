<?php echo e(json_encode($parseData, JSON_UNESCAPED_UNICODE)); ?>

