
<ul>
    <?php $__currentLoopData = $right; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li >
                <a href="<?php echo e($m->link); ?>"><span><?php echo e(($local=="ru")?$m->title:$m->title_en); ?></span></a>
            </li>


    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   <!--<li class="navOfferJS">
       <a><span>Пример</span></a>
        <p><a href="#">Impedit.</a></p>
    </li>-->

</ul>