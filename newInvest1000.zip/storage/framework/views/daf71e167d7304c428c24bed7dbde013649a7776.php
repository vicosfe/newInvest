<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="wrapperNews__content--item slideUp">
		<a href="/ru/news/<?php echo e($post->id); ?>">
			<div class="newsItem__img" style="background-image: url(<?php echo e($post->img); ?>);"></div>
			<div class="newsItem__info">
			<div class="newsItem__info--date"><p><?php echo e($post->created_at->formatLocalized('%d-%m-%y')); ?></p></div>
			<div class="newsItem__info--text"> <p><?php echo $post->title; ?></p></div>
			</div>
		</a>
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
