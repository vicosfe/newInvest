<?php $__env->startSection('content'); ?>
<!--  -->
<section style="height: calc(100% - 70px);margin-left: 105px;margin-top: 70px;">
	<?php echo $__env->make('admin.settingsTopPanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<section>
		<div class="addContent">
			<div class="addContent__header">
				<a href="/admin/home">
					<div class="addContent__header--arrow">
						<div class="imgArrow"></div>
					</div>
				</a>
				
				<ul>
					<li><a href="/admin/settings/opros">Настройка опроса</a></li>
					<li><a href="/admin/settings/usefullink">Настройка полезных ссылок</a></li>
					<li class="activeItem"><a href="/admin/settings/menu">Настройка пунктов меню</a></li>
					<li><a href="/admin/settings/ad">Настройка объявлений</a></li>
					<li><a href="/admin/settings/slide">Добавление слайда</a></li>
					<li><a href="/admin/settings/mail">Рассылка</a></li>
				</ul>
			</div>
		</div>
	</section>

	<section>
		<div class="settingsUsefulLinks">
			
			<div class="menuFormWrapper">
				<form action="/admin/settings/menu/add" class="settingsMenuFormAdd" method="POST">
					<?php echo e(csrf_field()); ?>

				<h3>Добавление пунктов меню</h3>
					<select name="menuSelect1" id="">
						<option value="0">Корень</option>
						<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($m->id); ?>"><?php echo e($m->title); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>

					<select name="typeMenu" id="typeMenu">
						<option value="1">Категория статей</option>
						<option value="4">Категория инвест. проектов</option>
						<option value="2">Уникальная страница</option>
						<option value="3">Ссылка</option>
					</select>

					<div class="settingsMenuFormAdd__group" id="ss3" style="display: none">
						<input type="text" name="link">
						<span class="highlight"></span>
						<span class="bar"></span>
						<label>Веедите ссылку</label>
					</div>

					<div class="settingsMenuFormAdd__group">      
						<input type="text" name="siteNameLink"  required >
						<span class="highlight"></span>
						<span class="bar"></span>
						<label>Название (рус)</label>
					</div>
					<div class="settingsMenuFormAdd__group">
						<input type="text" name="siteNameLinkEn"  required >
						<span class="highlight"></span>
						<span class="bar"></span>
						<label>Название (en)</label>
					</div>




					<button type="submit">Добавить пункт меню</button>

				</form>


				<form action="/admin/settings/menu/remove" class="settingsMenuFormDelete" method="POST">
					<h3>Удаление пунктов меню</h3>
					<?php echo e(csrf_field()); ?>

					<select name="menuSelectRemove1" id="menuSelectRemove1">
						<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($m->id); ?>"><?php echo e($m->title); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<select name="menuSelectRemove2" id="child<?php echo e($m->id); ?>" class="childs" style="display:none;">
								<option value="0">Удалить родителя</option>
								<?php $__currentLoopData = $m["items"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<option value="<?php echo e($mm->id); ?>"><?php echo e($mm->title); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<button type="submit">Удалить пункт меню</button>
				</form>

			</div>
			<div>
				<br><br>
				<h3>Редактирование  пунктов меню</h3>
				<form action="/admin/settings/menu/edit"  method="POST">
					<?php echo e(csrf_field()); ?>

				<table class="tm">
					<thead>

						<td>#</td>
						<td>Название (рус)</td>
						<td>Название (en)</td>
						<td>Ссылка</td>
						<td>Родитель</td>
						<td>Тип</td>
						<td>Приоритет</td>


					</thead>


						<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($m->id); ?></td>
								<td class="settingsMenuFormAdd__group"><input type="text" name="t<?php echo e($m->id); ?>" value="<?php echo e($m->title); ?>"><span class="highlight"></span>
									<span class="bar"></span></td>
								<td class="settingsMenuFormAdd__group"><input type="text" name="te<?php echo e($m->id); ?>" value="<?php echo e($m->title_en); ?>"><span class="highlight"></span>
									<span class="bar"></span></td>
								<td class="settingsMenuFormAdd__group"><input type="text" name="l<?php echo e($m->id); ?>" value="<?php echo e($m->link); ?>"><span class="highlight"></span>
									<span class="bar"></span></td>
								<td>
									<select name="par<?php echo e($m->id); ?>">
										<option value="0">Корень</option>
										<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mF): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<?php if($mF->id == $m->parrent_id): ?>
												<option value="<?php echo e($mF->id); ?>" selected><?php echo e($mF->title); ?></option>
											<?php else: ?>
												<option value="<?php echo e($mF->id); ?>"><?php echo e($mF->title); ?></option>
											<?php endif; ?>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>

								</td>
								<td>
									<?php if($m->type > 0): ?>
									<select name="type<?php echo e($m->id); ?>">
										<option value="1" <?php if($m->type == 1): ?> selected <?php endif; ?>>Категория статей</option>
										<option value="4" <?php if($m->type == 4): ?> selected <?php endif; ?>>Категория инвест.проектов</option>
										<option value="2" <?php if($m->type == 2): ?> selected <?php endif; ?>>Уникальная страница</option>
										<option value="3" <?php if($m->type == 3): ?> selected <?php endif; ?>>Ссылка</option>

									</select>
									<?php else: ?>
										<input type="hidden" name="type<?php echo e($m->id); ?>" value="0">
										Недоступно для изменения
									<?php endif; ?>
								</td>
								<td><input type="number" min="0" value="<?php echo e($m->priority); ?>" name="p<?php echo e($m->id); ?>"></td>


							</tr>
							<?php $__currentLoopData = $m["items"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e($mm->id); ?></td>
									<td class="settingsMenuFormAdd__group"><input type="text" name="t<?php echo e($mm->id); ?>" value="<?php echo e($mm->title); ?>"><span class="highlight"></span>
										<span class="bar"></span></td>
									<td class="settingsMenuFormAdd__group"><input type="text" name="te<?php echo e($mm->id); ?>" value="<?php echo e($mm->title_en); ?>"><span class="highlight"></span>
										<span class="bar"></span></td>
									<td class="settingsMenuFormAdd__group"><input type="text" name="l<?php echo e($mm->id); ?>" value="<?php echo e($mm->link); ?>"><span class="highlight"></span>
										<span class="bar"></span></td>
									<td>
										<select name="par<?php echo e($mm->id); ?>">
											<option value="0">Корень</option>
											<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mF): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($mF->id == $mm->parrent_id): ?>
													<option value="<?php echo e($mF->id); ?>" selected><?php echo e($mF->title); ?></option>
												<?php else: ?>
													<option value="<?php echo e($mF->id); ?>"><?php echo e($mF->title); ?></option>
													<?php endif; ?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</select>
									</td>
									<td>
										<?php if($mm->type > 0): ?>
										<select name="type<?php echo e($mm->id); ?>">
											<option value="1" <?php if($mm->type == 1): ?> selected <?php endif; ?>>Категория статей</option>
											<option value="4" <?php if($mm->type == 4): ?> selected <?php endif; ?>>Категория инвест.проектов</option>
											<option value="2" <?php if($mm->type == 2): ?> selected <?php endif; ?>>Уникальная страница</option>
											<option value="3" <?php if($mm->type == 3): ?> selected <?php endif; ?>>Ссылка</option>

										</select>
										<?php else: ?>
											<input type="hidden" name="type<?php echo e($mm->id); ?>" value="0">
											Недоступно для изменения
										<?php endif; ?>
									</td>
									<td><input type="number" min="0" value="<?php echo e($mm->priority); ?>" name="p<?php echo e($mm->id); ?>"></td>

								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				</table>
					<br><br>
					<div class="settingsMenuFormDelete"><button type="submit">Сохранить</button></div>
					<br><br>
				</form>
			</div>
			<script>
                $(document).ready(function(){

                    $("#menuSelectRemove1").on("change",function () {
                        $(".childs").not("#child"+$(this).val()).hide();
                        $(".childs").not("#child"+$(this).val()).attr("disabled","disabled");
                        $("#child"+$(this).val()).show();
                        $("#child"+$(this).val()).removeAttr("disabled");
                    })

                    $("#typeMenu").on("change",function () {
                       if($(this).val()=="3"){
						$("#ss3").slideDown();
					   }
					   else if($("#ss3").is(":visible")){
                           $("#ss3").slideUp();
					   }
                    })


                })
			</script>


			<!--  -->
			<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminWrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>