<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;

class Answer extends Model
{
    public $timestamps = false;

}
