<?php


namespace App\Http\Controllers;

use App;
use App\Menu;
use Illuminate\Http\Request;
use Mcamara\LaravelLocalization\Facades\LaravelLocalization;
class MenuController extends Controller
{



}
