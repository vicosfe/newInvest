<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;

class Media_Project extends Model
{
    public $timestamps = false;

}
