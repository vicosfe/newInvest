<?php
return [

    'heading_useful_links' => 'Useful links',
    'president_site' => 'President RF',
    'goverment_site' => 'Goverment RF',
    'goverment_rd_site' => 'Goverment of Dagestan',
    'makhachkala_news' => 'Makhachkala news', 
    'fscn_site' => 'FSKN',
    'skfo_site' => 'SKFO.ru',
    'russian_public_initiative' => 'Russian Public Initiative',
    'public_oversight' => 'Public oversight',
    'makhachkala_mfc' => 'Makhachkala MFC',
    'main_portal' => 'Main internet portal of the regions of Russia',
    'state_portal' => 'Portal of state municipal institutions',
    'tourism_center' => 'City Tourism Center',
    'business_support' => 'Portal for business support',
    'site_ogv_omsu' => 'Single site of the state body and local self-government',
    'ocenka_regular_vozdeistviya' => 'Regulatory Impact Assessment',
    'input_search' => 'Non-commercial fund of capital repairs of property MCD',
    'btn_find' => 'Work in Russia',
    'btn_feedback' => 'The Prosecutor\'s Office', 
    'btn_hotline' => 'Data bank of executive production',
    'btn_download' => 'The Commissioner for the Protection of the Rights of Entrepreneurs',
    'btn_load_more' => 'State services',
    'btn_load_more' => 'State procurement'

];