	<section>
		<div class="addDescription">
			<div class="addDescription__img">
				<div class="addDescription__img--block"></div>	
			</div>
			<div class="addDescription__text">
				<h3>Добавление контента</h3>
				<p>Здесь вы можете добавить информацию во все разделы сайта.</p>
			</div>
		</div>	
	</section>