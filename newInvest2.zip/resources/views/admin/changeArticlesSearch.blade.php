	<div class="changeArticles__wrapper">
		<h3>Редактирование статьи</h3>
		<form action="#" class="searchArticlesForm">
			<div class="searchArticlesForm__group">      
				<input type="text" name="searchArticles"  required >
				<span class="highlight"></span>
				<span class="bar"></span>
				<label>Поиск</label>
				<i class="fa fa-search" aria-hidden="true"></i>
			</div>
		</form>
	</div>


	<div class="articlesContent">
		<a href="#">
			<div class="articlesContentItem">

				<div class="hrAdm"></div>
				<div class="articlesContentItem__wrapper">
					<div class="articlesContentItem__left">
						<p>Тут будет заголовок статьи</p>
					</div>
					<div class="articlesContentItem__center">23 Марта 2017г</div>
					<div class="articlesContentItem__right">
						<div class="articlesContentItem__right--change">
							<p>Редактировать</p>
						</div>
						<div class="articlesContentItem__right--delete">
							<p>Удалить</p>
						</div>
					</div>
				</div>
				<div class="hrAdm"></div>
			</div>
		</a>

		<a href="#">
			<div class="articlesContentItem">

				<div class="hrAdm"></div>
				<div class="articlesContentItem__wrapper">
					<div class="articlesContentItem__left">
						<p>Тут будет заголовок статьи</p>
					</div>
					<div class="articlesContentItem__center">23 Марта 2017г</div>
					<div class="articlesContentItem__right">
						<div class="articlesContentItem__right--change">
							<p>Редактировать</p>
						</div>
						<div class="articlesContentItem__right--delete">
							<p>Удалить</p>
						</div>
					</div>
				</div>
				<div class="hrAdm"></div>
			</div>
		</a>

		<a href="#">
			<div class="articlesContentItem">

				<div class="hrAdm"></div>
				<div class="articlesContentItem__wrapper">
					<div class="articlesContentItem__left">
						<p>Тут будет заголовок статьи</p>
					</div>
					<div class="articlesContentItem__center">23 Марта 2017г</div>
					<div class="articlesContentItem__right">
						<div class="articlesContentItem__right--change">
							<p>Редактировать</p>
						</div>
						<div class="articlesContentItem__right--delete">
							<p>Удалить</p>
						</div>
					</div>
				</div>
				<div class="hrAdm"></div>
			</div>
		</a>




	</div>