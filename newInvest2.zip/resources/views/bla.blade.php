





<div class="sideBarLeftMain">
    <a href="#">
        <div class="sideBarLeftMain__item" style="background-image: url(/public/images/sitebar_left1.png);">
            <div class="sideBarLeftMain__item--content">
                <div class="content__border"></div>
                <div class="content__text">

                    <span> <b>Единое</b> окно</span>
                    <p>Предложить инвестиционный проект</p>

                </div>
            </div>
            <div class="sideBarLeftMain__item--blockFilter">
            </div>
        </div>
    </a>

    <a href="#">
        <div class="sideBarLeftMain__item" style="background-image: url(/public/images/sitebar_left2.png);">
            <div class="sideBarLeftMain__item--content">
                <div class="content__border"></div>
                <div class="content__text">
                    <div class="content__text--div"> Инфраструктура поддержки предпринимательства</div>
                </div>
            </div>
            <div class="sideBarLeftMain__item--blockFilter">
            </div>
        </div>
    </a>

    <a href="#">
        <div class="sideBarLeftMain__item" style="background-image: url(/public/images/sitebar_left3.png);">
            <div class="sideBarLeftMain__item--content">
                <div class="content__border"></div>
                <div class="content__text">
                    <div class="content__text--div">о махачкале</div>
                </div>
            </div>
            <div class="sideBarLeftMain__item--blockFilter">
            </div>
        </div>
    </a>

    <a href="/ru/logistika">
        <div class="sideBarLeftMain__item" style="background-image: url(/public/images/sitebar_left4.png);">
            <div class="sideBarLeftMain__item--content">
                <div class="content__border"></div>
                <div class="content__text">
                    <div class="content__text--div"> Логистика</div>
                </div>
            </div>
            <div class="sideBarLeftMain__item--blockFilter"></div>
        </div>
    </a>
</div>

<!--**********************БЛОК НОВОСТЕЙ ******************-->


<div class="wrapperNews1121 grid effect-4" id="grid">
    <!--**********************БЛОК сайдбара (левый)******************-->



    <div class="grid-item top__itemSmall" style="background-image: url(/public/images/news1.png);">
        <div class="top__itemSmall--text">
            <div>В КАЛУЖСКОЙ ОБЛАСТИ ОТКРЫТО <br> РОССИЙСКО-ЧЕШСКОЕ ПРЕДПРИЯТИЕ ПО ВЫПУСКУ САНИТАРНОЙ КЕРАМИКИ</div>
        </div>
        <div class="top__itemSmall--blockFilter"></div>
        <a href="#"></a>
    </div>


    <div class="grid-item top__itemSmall" style="background-image: url(/public/images/news2.png);">
        <div class="top__itemSmall--text">
            <div>ДЕНЬ ОТКРЫТЫХ ДВЕРЕЙ В КАЛУЖСКОМ КОЛЛЕДЖЕ СЕРВИСА И ДИЗАЙНА С КОМПАНИЕЙ БОСКО</div>
        </div>
        <div class="top__itemSmall--blockFilter"></div>
        <a href="#"></a>
    </div>




    <div class="top__itemLarge grid-item" style="background-image: url(/public/images/news3.png);">
        <div class="top__itemLarge--text">
            <div>АНАТОЛИЙ АРТАМОНОВ: «В КАЖДОМ УГОЛКЕ НАШЕЙ ОБЛАСТИ ТРУДЯТСЯ ТАЛАНТЛИВЫЕ ЛЮДИ»</div>
        </div>
        <div class="top__itemLarge--blockFilter"></div>
        <a href="#"></a>
    </div>

    <div class="top__itemLarge grid-item" style="background-image: url(/public/images/news3.png);">
        <div class="top__itemLarge--text">
            <div>АНАТОЛИЙ АРТАМОНОВ: «В КАЖДОМ УГОЛКЕ НАШЕЙ ОБЛАСТИ ТРУДЯТСЯ ТАЛАНТЛИВЫЕ ЛЮДИ»</div>
        </div>
        <div class="top__itemLarge--blockFilter"></div>
        <a href="#"></a>
    </div>

    <div class="grid-item top__itemSmall" style="background-image: url(/public/images/news4.png);">
        <div class="top__itemSmall--text">
            <div>ДЕНЬ ОТКРЫТЫХ ДВЕРЕЙ В КАЛУЖСКОМ КОЛЛЕДЖЕ СЕРВИСА И ДИЗАЙНА С КОМПАНИЕЙ БОСКО</div>
        </div>
        <div class="top__itemSmall--blockFilter"></div>
        <a href="#"></a>
    </div>

    <div class="grid-item top__itemSmall" style="background-image: url(/public/images/news5.png);">
        <div class="top__itemSmall--text">
            <div>ДЕНЬ ОТКРЫТЫХ ДВЕРЕЙ В КАЛУЖСКОМ КОЛЛЕДЖЕ СЕРВИСА И ДИЗАЙНА С КОМПАНИЕЙ БОСКО</div>
        </div>
        <div class="top__itemSmall--blockFilter"></div>
        <a href="#"></a>
    </div>

    <div class="grid-item top__itemSmall" style="background-image: url(/public/images/news4.png);">
        <div class="top__itemSmall--text">
            <div>ДЕНЬ ОТКРЫТЫХ ДВЕРЕЙ В КАЛУЖСКОМ КОЛЛЕДЖЕ СЕРВИСА И ДИЗАЙНА С КОМПАНИЕЙ БОСКО</div>
        </div>
        <div class="top__itemSmall--blockFilter"></div>
        <a href="#"></a>
    </div>

    <div class="grid-item top__itemSmall" style="background-image: url(/public/images/news5.png);">
        <div class="top__itemSmall--text">
            <div>ДЕНЬ ОТКРЫТЫХ ДВЕРЕЙ В КАЛУЖСКОМ КОЛЛЕДЖЕ СЕРВИСА И ДИЗАЙНА С КОМПАНИЕЙ БОСКО</div>
        </div>
        <div class="top__itemSmall--blockFilter"></div>
        <a href="#"></a>
    </div>




</div>
