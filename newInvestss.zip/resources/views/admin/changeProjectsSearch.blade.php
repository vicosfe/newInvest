<div class="changeUniquePages__wrapper">
	<h3>Редактирование проекта</h3>
	<form action="#" class="searchProjectForm">
		<div class="searchProjectForm__group">      
			<input type="text" name="searchProjectPages"  required >
			<span class="highlight"></span>
			<span class="bar"></span>
			<label>Поиск</label>
			<i class="fa fa-search" aria-hidden="true"></i>
		</div>
	</form>
</div>


<div class="projectContent">
	<a href="#">
		<div class="projectContentItem">

			<div class="hrAdm"></div>
			<div class="projectContentItem__wrapper">
				<div class="projectContentItem__left">
					<p>Тут будет заголовок статьи</p>
				</div>
				<div class="projectContentItem__center">23 Марта 2017г</div>
				<div class="projectContentItem__right">
					<div class="projectContentItem__right--change">
						<p>Редактировать</p>
					</div>
					<div class="projectContentItem__right--delete">
						<p>Удалить</p>
					</div>
				</div>
			</div>
			<div class="hrAdm"></div>
		</div>
	</a>

	<a href="#">
		<div class="projectContentItem">

			<div class="hrAdm"></div>
			<div class="projectContentItem__wrapper">
				<div class="projectContentItem__left">
					<p>Тут будет заголовок статьи</p>
				</div>
				<div class="projectContentItem__center">23 Марта 2017г</div>
				<div class="projectContentItem__right">
					<div class="projectContentItem__right--change">
						<p>Редактировать</p>
					</div>
					<div class="projectContentItem__right--delete">
						<p>Удалить</p>
					</div>
				</div>
			</div>
			<div class="hrAdm"></div>
		</div>
	</a>

	<a href="#">
		<div class="projectContentItem">

			<div class="hrAdm"></div>
			<div class="projectContentItem__wrapper">
				<div class="projectContentItem__left">
					<p>Тут будет заголовок статьи</p>
				</div>
				<div class="projectContentItem__center">23 Марта 2017г</div>
				<div class="projectContentItem__right">
					<div class="projectContentItem__right--change">
						<p>Редактировать</p>
					</div>
					<div class="projectContentItem__right--delete">
						<p>Удалить</p>
					</div>
				</div>
			</div>
			<div class="hrAdm"></div>
		</div>
	</a>




</div>