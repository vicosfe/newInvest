
<div class="changeNews__wrapper">
	<h3>Редактирование новости</h3>
	<form action="#" class="searchNewsForm">
		<div class="searchNewsForm__group">      
			<input type="text" name="searchNews"  required >
			<span class="highlight"></span>
			<span class="bar"></span>
			<label>Поиск</label>
			<i class="fa fa-search" aria-hidden="true"></i>
		</div>
	</form>
</div>
<div class="wrapperNews__content">

	<div class="wrapperNews__content--item">
		<div class="deleteNews">
			<a href="#">x</a>
		</div>
		<a href="#">
			<div class="newsItem__img" style="background-image: url(../../public/images/news/1.jpg);"></div>
			<div class="newsItem__info">
				<div class="newsItem__info--date"><p>111111</p></div>
				<div class="newsItem__info--text"> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Esse, hic.</p></div>
			</div>
		</a>
	</div> 

	<div class="wrapperNews__content--item">
		<div class="deleteNews">
			<a href="#">x</a>
		</div>
		<a href="#">
			<div class="newsItem__img" style="background-image: url(../../public/images/news/1.jpg);"></div>
			<div class="newsItem__info">
				<div class="newsItem__info--date"><p>111111</p></div>
				<div class="newsItem__info--text"> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptas minima maxime inventore quasi animi rem.</p></div>
			</div>
		</a>
	</div>

	<div class="wrapperNews__content--item">
		<div class="deleteNews">
			<a href="#">x</a>
		</div>
		<a href="#">
			<div class="newsItem__img" style="background-image: url(../../public/images/news/1.jpg);"></div>
			<div class="newsItem__info">
				<div class="newsItem__info--date"><p>111111</p></div>
				<div class="newsItem__info--text"> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quia animi non expedita, cupiditate quisquam maiores!</p></div>
			</div>
		</a>
	</div>

	<div class="wrapperNews__content--item">
		<div class="deleteNews">
			<a href="#">x</a>
		</div>
		<a href="#">
			<div class="newsItem__img" style="background-image: url(../../public/images/news/1.jpg);"></div>
			<div class="newsItem__info">
				<div class="newsItem__info--date"><p>111111</p></div>
				<div class="newsItem__info--text"> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quo natus quae voluptates, eveniet, amet esse.</p></div>
			</div>
		</a>
	</div>

	<div class="wrapperNews__content--item">
		<div class="deleteNews">
			<a href="#">x</a>
		</div>
		<a href="#">
			<div class="newsItem__img" style="background-image: url(../../public/images/news/1.jpg);"></div>
			<div class="newsItem__info">
				<div class="newsItem__info--date"><p>111111</p></div>
				<div class="newsItem__info--text"> <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eum, cum consequuntur vel. Magni nihil, mollitia.</p></div>
			</div>
		</a>
	</div>


	

</div>