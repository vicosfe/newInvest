<?php $__env->startSection('content'); ?>
<main class="newsPage">
	<div class="CAPTION">
		<div class="centerBlock">
			<div class="CAPTION__wrapper">
				<p>
					Новости
				</p>
			</div>
		</div>
	</div>

	<section class="centerBlock">
		<div class="wrapperNews">
			<div class="wrapperNews__content">
				<?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<div class="wrapperNews__content--item">
					<a href="/ru/news/<?php echo e($post->id); ?>">
						<div class="newsItem__img" style="background-image: url(<?php echo e($post->img); ?>);"></div>
						<div class="newsItem__info">
							<div class="newsItem__info--date"><p><?php echo e($post->created_at->formatLocalized('%d-%m-%y')); ?></p></div>
							<div class="newsItem__info--text"> <p><?php echo $post->title; ?></p></div>
						</div>
					</a>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
	</section>
	<section>
		<div class="loadMoreNews">
			<a class="loadMoreNews-js" href="#"  data-page ="<?php echo e($page); ?>">загрузить еще</a>
		</div>
	</section>
	<?php echo $__env->make('usefulLinks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('wrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>