<?php $__env->startSection('main'); ?>
	<div class="uniqueDescription">
		<p><?php echo e($page->title); ?></p>
	</div>
	<div class="supportMain">
		<?php if(count($paths)): ?>
			<?php $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="supportMain__item">
				<a href="#">
					<div class="wrapSup supMsub supMclose">
						<div class="supportMain__item--text">
							<?php echo e($path->title); ?>

						</div>
					</div>
				</a>
				<div class="supportMain__item--sub">
					<?php if(count($path->docs)): ?>
						<?php $__currentLoopData = $path->docs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<a href="<?php echo e($doc->link); ?>" target="_blank">
								<p><?php echo e($doc->title); ?></p>
								<div class="itemSubRight">
									<img src="/public/images/linkFile.png" alt="">
									<p>Скачать</p>
								</div>
							</a>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					<?php endif; ?>
					<?php if(strlen($path->description)): ?>
						<div class="subDescription">
							<p><?php echo e($path->description); ?></p>
						</div>
					<?php endif; ?>
				</div>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<?php endif; ?>
	</div>

	<?php $__env->stopSection(); ?>
<?php echo $__env->make('uniquepage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>