<?php $__env->startSection('content'); ?>
<?php echo $__env->make('bigSlider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('feedBackForm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<section>
  <div class="downNavigation centerBlock">
    <nav>
      <ul>
        <li class="downNavigation__item">
          <a href="#">
            <div class="downNavWrapper">
             <div class="downNavigation__item-img1 downNavIcon"></div>
             <div class="downNavigation__item-text">Путеводитель инвестора</div>
           </div>
         </a>
       </li>
       <li class="downNavigation__item">
        <a href="/article/1">
          <div class="downNavWrapper">
            <div class="downNavigation__item-img2 downNavIcon"></div>
            <div class="downNavigation__item-text">О Махачкале</div>
          </div>
        </a>
      </li>
      <li class="downNavigation__item">
        <a href="#">
          <div class="downNavWrapper">
            <div class="downNavigation__item-img3 downNavIcon"></div>
            <div class="downNavigation__item-text">Бизнес-навигатор</div>
          </div>
        </a>
      </li>
      <li class="downNavigation__item singleWindJS">
        <a href="#">
          <div class="downNavWrapper">
           <div class="downNavigation__item-img4 downNavIcon"></div>
           <div class="downNavigation__item-text">Единое окно</div>
         </div>
       </a>
     </li>
   </ul>
 </nav>
</div>

</section>

<section class="mainPageCenterContent">
  <div class="centerContent centerBlock">
   <div class="centerContent__wrapper">
    <div class="AttentionOfCitizens">
      <div class="AttentionOfCitizens__wrapper">
        <div class="AttentionOfCitizens__wrapper--left">
          <p>!</p>
        </div>
        <div class="AttentionOfCitizens__wrapper--right">
          <h3>Вниманию горожан!</h3>
          <p>Махачкалинские электросети обращают внимание жителей города, а также руководителей различных форм собственности на то, что за период с января по апрель 2017 г. нами было зафиксировано 10 технологических нарушений (аварий) в электрических сетях города, произошедших вследствие различного рода воздействий на них посторонними лицами и организациями. </p>
        </div>
      </div>
    </div>
    <div class="centerContent__wrapper--leftContent">

     <!--**********************БЛОК сайдбара (левый)******************-->



     <!--**********************БЛОК НОВОСТЕЙ ******************-->

        <div class="centerContent__news ">
            <div class="top__itemSmall" style="background-image: url(<?php echo e($news[0]->img); ?>);">
                <div class="top__itemSmall--text">
                    <div><?php echo $news[0]->title; ?></div>
                </div>
                <div class="top__itemSmall--blockFilter"></div>
                <a href="/news/<?php echo e($news[0]->id); ?>"></a>
            </div>


            <div class="top__itemSmall" style="background-image: url(<?php echo e($news[1]->img); ?>);">
                <div class="top__itemSmall--text">
                    <div><?php echo $news[1]->title; ?></div>
                </div>
                <div class="top__itemSmall--blockFilter"></div>
                <a href="/news/<?php echo e($news[1]->id); ?>"></a>
            </div>


            <div class="top__itemSmall" style="background-image: url(<?php echo e($news[2]->img); ?>);">
                <div class="top__itemSmall--text">
                    <div><?php echo $news[2]->title; ?></div>
                </div>
                <div class="top__itemSmall--blockFilter"></div>
                <a href="/news/<?php echo e($news[2]->id); ?>"></a>
            </div>



            <div class="top__itemLarge" style="background-image: url(<?php echo e($news[3]->img); ?>);">
                <div class="top__itemLarge--text">
                    <div><?php echo $news[3]->title; ?></div>
                </div>
                <div class="top__itemLarge--blockFilter"></div>
                <a href="/news/<?php echo e($news[3]->id); ?>"></a>
            </div>

            <div class="top__itemSmall" style="background-image: url(<?php echo e($news[4]->img); ?>);">
                <div class="top__itemSmall--text">
                    <div><?php echo $news[4]->title; ?></div>
                </div>
                <div class="top__itemSmall--blockFilter"></div>
                <a href="/news/<?php echo e($news[4]->id); ?>"></a>
            </div>
            <div class="top__itemSmall" style="background-image: url(<?php echo e($news[5]->img); ?>);">
                <div class="top__itemSmall--text">
                    <div><?php echo $news[5]->title; ?></div>
                </div>
                <div class="top__itemSmall--blockFilter"></div>
                <a href="/news/<?php echo e($news[5]->id); ?>"></a>
            </div>

            <div class="top__itemLarge" style="background-image: url(<?php echo e($news[6]->img); ?>);">
                <div class="top__itemLarge--text">
                    <div><?php echo $news[6]->title; ?></div>
                </div>
                <div class="top__itemLarge--blockFilter"></div>
                <a href="/news/<?php echo e($news[6]->id); ?>"></a>
            </div>

            <div class="top__itemSmall" style="background-image: url(<?php echo e($news[7]->img); ?>);">
                <div class="top__itemSmall--text">
                    <div><?php echo $news[7]->title; ?></div>
                </div>
                <div class="top__itemSmall--blockFilter"></div>
                <a href="/news/<?php echo e($news[7]->id); ?>"></a>
            </div>


            <div class="top__itemSmall" style="background-image: url(<?php echo e($news[8]->img); ?>);">
                <div class="top__itemSmall--text">
                    <div><?php echo $news[8]->title; ?></div>
                </div>
                <div class="top__itemSmall--blockFilter"></div>
                <a href="/news/<?php echo e($news[8]->id); ?>"></a>
            </div>


            <div class="top__itemSmall" style="background-image: url(<?php echo e($news[9]->img); ?>);">
                <div class="top__itemSmall--text">
                    <div><?php echo $news[9]->title; ?></div>
                </div>
                <div class="top__itemSmall--blockFilter"></div>
                <a href="/news/<?php echo e($news[9]->id); ?>"></a>
            </div>


        </div>

  </div>



</div> 




<!--**********************БЛОК сайдбара(правый)******************-->

<div class="sideBarMainRight">
    <?php if(count($poll)): ?>
      <div class="question">
        <div class="question__caption">
          <h2>Опрос</h2>
        </div>
        <form action="#" class="questionForm" method="POST">
            <?php echo e(csrf_field()); ?>

          <p><?php echo e($poll->title); ?></p>
            <?$data = json_decode($poll->data);?>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="inpWrapper">
            <input  name="question" type="radio" value="<?php echo e($d); ?>" id="kredit<?php echo e($d); ?>"> <label for="kredit<?php echo e($d); ?>"><?php echo e($d); ?></label>
          </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <input type="hidden" name="poll_id" value="<?php echo e($poll->id); ?>">
          <button class="replyButton">Ответить</button>
        </form>

    <?php elseif(count($result)): ?>
        <div class="question">
            <div class="question__caption">
                <h2>Опрос</h2>
            </div>
            <p><?php echo e($result["title"]); ?></p>
        <?php $__currentLoopData = $result["items"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="inpWrapper">
               <p <?php if($answ->value == $r["title"]): ?> style="border:1px solid red" <?php endif; ?>><?php echo e($r["title"]); ?> - <?php echo e($r["res"]); ?>%</p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endif; ?>
  <!-- НОВОСТИ С МКАЛА -->
  <div class="newsMKALA">
    <div class="newsMKALA__caption">
      <h2>Новости с mkala</h2>
    </div>
    <div class="newsMKALA__newsBlock load ">
      <div class="newsMKALA__newsBlock--content load"></div>
      <div class="linkInMkalaNews"><a target="_blank" href="http://www.mkala.ru/info/news/">Посмотреть еще</a></div>    
    </div>

  </div>
  <div class="dispatch">
    <div class="dispatch__wrapper">
      <div class="dispatch__wrapper--caption">
        <h3>Рассылка</h3>
      </div>
      <div class="dispatch__wrapper--description">
        <p>
          Подпишитесь на рассылку и получайте последние новости первыми.
        </p>
      </div>
      <div class="dispatch__form">
        <form action="#">
          <div class="dispatch__inputWrapper">
            <input id="dispatch__form--text" type="email" required="" placeholder=" ">
            <label class="dispatch__form--label" for="dispatch__form--text">Email</label> 
            
          </div>
          <button type="submit">Отправить</button>
        </form>
      </div>
    </div>
  </div>

</div>
</div>
</section>

<script>

</script>
<div class="wrapper__media centerBlock">
    <h2>МЕДИА</h2>

    <?php if(count($media)): ?><div class="media" ><?php echo $__env->make('mediaSlide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div><?php endif; ?>
</div>
<?php echo $__env->make('usefulLinks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('wrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>