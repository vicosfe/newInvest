<section>
    <div class="usefulLinks centerBlock">
        <h2>ПОЛЕЗНЫЕ ССЫЛКИ</h2>
        <div class="usefulLinks__wrapper">
            <?php $__currentLoopData = $linkItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="usefulLinks__wrapper--item">
                    <a href="<?php echo e($item->link); ?>" target="_blank"></a>
                    <div class="usefulLinks__item--logo">
                        <img src="<?php echo e($item->img); ?>" alt="">
                    </div>
                    <div class="usefulLinks__item--text">
                        <?php echo e($item->title); ?><br>
                        <?php echo e($item->link); ?>

                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>


    </div>

</section>