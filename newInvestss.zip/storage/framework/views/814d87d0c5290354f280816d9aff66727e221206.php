<?php $__env->startSection('content'); ?>

	<section>
		<div class="cardNewsWrapper">
			<div class="wrapperCaptionNews">
				<div class="cardNewsWrapper__cardNews--description centerBlock">
					<h3>
						<?php echo $item->title; ?>

					</h3>
				</div>
			</div>
			<?php if(count($media)): ?><div class="media centerBlock"><?php echo $__env->make('mediaSlide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div><br><br><?php endif; ?>
			<div class="cardNewsWrapper__cardNews centerBlock">

				<div class="cardNewsWrapper__cardNews--text">
					<?php echo $item->content; ?>

				</div>
			</div>

		</div>
	</section>



	<?php echo $__env->make('usefulLinks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('wrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>