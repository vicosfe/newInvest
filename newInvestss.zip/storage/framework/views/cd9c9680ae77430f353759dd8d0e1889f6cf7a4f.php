<?php $__env->startSection('content'); ?>
<!-- ************************************************************************************** -->

<section>
	<div class="centerBlock">
		<form  class="searchForm" action="/search" method="POST">
			<?php echo e(csrf_field()); ?>

			<div class="search__group">      
				<input type="text" name="mainSearch" required>
				<span class="highlight"></span>
				<span class="bar"></span>
				<label class="feedBackLabel">Поиск</label>
			</div>
			<button type="submit">Найти</button>

		</form>
	</div>
</section>


<section>
	<div class="centerBlock">
		<div class="searchContent">
		<?php if(count($result)): ?>
			<?php $__currentLoopData = $result["articles"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

			<div class="searchContent__item1">
				<a href="/articles/<?php echo e($item->id); ?>">
					<div class="searchContent__item1--left" style="background-image: url(<?php echo e($item->img); ?>);"></div>
					<div class="searchContent__item1--right">
						<h4><?php echo e($item->title); ?></h4>
						<p><?php echo mb_substr($item->description, 0, 200); ?>...</p>
						<span><?php echo e($item->created_at->formatLocalized('%d-%m-%y')); ?></span>
					</div>
				</a>
			</div>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php $__currentLoopData = $result["news"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<div class="searchContent__item1">
						<a href="/news/<?php echo e($item->id); ?>">
							<div class="searchContent__item1--left" style="background-image: url(<?php echo e($item->img); ?>);"></div>
							<div class="searchContent__item1--right">
								<h4><?php echo e($item->title); ?></h4>
								<p><?php echo mb_substr($item->content, 0, 200); ?>...</p>
								<span><?php echo e($item->created_at->formatLocalized('%d-%m-%y')); ?></span>
							</div>
						</a>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				<?php $__currentLoopData = $result["docs"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="searchContent__item2">
				<a href="<?php echo e($item->link); ?>">
					<div class="searchContent__item2--left">
						<img src="public/images/linkFile.png" alt="">
					</div>
					<div class="searchContent__item2--right">
						<p><?php echo e($item->title); ?></p>
					</div>
				</a>
			</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
			<p>Нет результатов</p>
		<?php endif; ?>
		</div>	
	</div>
</section>





<!-- ************************************************************************************** -->
<?php echo $__env->make('usefulLinks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('wrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>