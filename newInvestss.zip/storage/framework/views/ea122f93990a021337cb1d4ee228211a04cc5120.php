<?php $__env->startSection('content'); ?>
<!-- ************************************************************************************** -->
<?php if(count($cat)): ?>
<div class="CAPTION">
	<div class="centerBlock">
		<div class="CAPTION__wrapper">
			<p>
				<?php echo e($cat->title); ?>

			</p>
		</div>
	</div>
</div>
<?php endif; ?>
<div class="centerBlock">
	<div class="investOfferContainer">
		<div class="offer_left">
			<?php echo $__env->make('rightMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
		<div class="offer_right">

		<!-- Подключение вьюх -->
	<?php echo $__env->yieldContent('main'); ?>
		</div>

	</div>
	

</div>





<!-- ************************************************************************************** -->
<?php echo $__env->make('usefulLinks', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('wrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>