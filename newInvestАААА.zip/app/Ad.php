<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;

class Ad extends Model
{
    public $timestamps = false;

}
