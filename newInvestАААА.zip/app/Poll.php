<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;

class Poll extends Model
{
    public $timestamps = false;

}
