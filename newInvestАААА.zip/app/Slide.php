<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Pagination\Paginator;

class Slide extends Model
{
    public $timestamps = false;

}
