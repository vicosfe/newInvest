<section>
	<div class="notificationDescription">
		<div class="notificationDescription__img">
			<div class="notificationDescription__img--block"></div>	
		</div>
		<div class="notificationDescription__text">
			<h3>Заявки</h3>
			<p>здесь вы можете посмотреть все поступившие заявки с сайта.</p>
		</div>
	</div>	
</section>