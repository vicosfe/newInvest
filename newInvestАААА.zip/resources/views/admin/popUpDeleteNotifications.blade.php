<div class="box_popUpDelNews">
	<div class="popUpDelNews">
		<div class="popUpDelNewsWrapper">
			<h3>Вы действительно хотите удалить?</h3>
			<div class="popUpDelNews__link">
				<a href="#"  class="dontDelete">Нет, не удалять</a>
				<a href="#" class="linkremove">Да, удалить</a>
			</div>
		</div>
	</div>
</div>
