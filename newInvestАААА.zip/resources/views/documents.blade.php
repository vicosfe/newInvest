@extends('wrap')
@section('content')
<!-- ************************************************************************************** -->
<div class="CAPTION">
	<div class="centerBlock">
		<div class="CAPTION__wrapper">
			<p>
				Документы
			</p>
		</div>
	</div>
</div>

<section>
	<div class="centerBlock">
		<div class="docWrapper">


			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			<div class="documentItem">
				<a href="#">
					<div class="documentItem__text">Здесь будет название документа</div>
					<div class="documentItem__img">
						<img src="../public/images/linkFile.png" alt="">
						<p>Скачать</p>
					</div>
				</a>
			</div>

			

		</div>
		
	</div>
</section>

<!-- ************************************************************************************** -->
@include('usefulLinks')


@stop