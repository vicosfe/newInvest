<?php $__env->startSection('main'); ?>

<section class="projIvs">
	<?php if(count($items)): ?>
		<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<a href="/article/<?php echo e($item->id); ?>">
				<div class="tab-item-investmentPro__item">
					<div class="tab-item-investmentPro__item--img" style="background-image: url(<?php echo e($item->img); ?>);"></div>
					<div class="tab-item-investmentPro__item--text">
						<?php echo e($item->title); ?>

					</div>
				</div>
			</a>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<div class="loadMoreNews">
				<a class="loadMoreNews-js" href="#">загрузить еще</a>
			</div>
	<?php else: ?>

		<p class="empty">Пока нет записей</p>

	<?php endif; ?>





</section>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('uniquePage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>