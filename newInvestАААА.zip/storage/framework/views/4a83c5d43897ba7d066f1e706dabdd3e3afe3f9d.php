<?php $__env->startSection('main'); ?><!--  Уникальная страница -->
<section>
    <?php if(count($media)): ?><div class="media" style="height: 432px;"><?php echo $__env->make('mediaSlide', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div><?php endif; ?>

        <?$data = json_decode($item->description);?>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="objectivesProj">
                <h3><?php echo e($d->title); ?></h3>
                <p><?php echo $d->d; ?></p>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <div class="costProject">
        <h3>ОРИЕНТИРОВАЧНАЯ СТОИМОСТЬ ПРОЕКТА</h3>
        <p><?php echo e($item->price); ?></p>
        <button class="OpenPopUpForm">СТАТЬ ИНВЕСТОРОМ</button>
    </div>
</section>
<!--************************** PopUp form **************************-->
    <div class="goInvestForm">
        <div class="goInvestFormBlock">
            <h3>Стать инвестором <div class="goInvestFormBlockCloseForm"></div></h3>
            <div class="sendMessage">
                <p>Отправьте сообщение</p>
            </div>

            <form action="/messages/project" method="POST" class="goInvForm">
                <?php echo e(csrf_field()); ?>

                <div class="goInvForm__group">   
                    <input type="text" name="goInvFormFIO"  required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Фамилия Имя Отчество</label>
                </div>


                <div class="goInvForm__group">      
                    <input type="email" name="goInvFormEmail" class="goInvFormEmail"  required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label class="goInvFormLabel">Email</label>
                </div>

                <div class="goInvForm__group">   
                    <input type="text" name="goInvFormCompany"  required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Компания</label>
                </div>

                <div class="goInvForm__group">   
                    <input type="text" name="goInvFormMessage"  required>
                    <span class="highlight"></span>
                    <span class="bar"></span>
                    <label>Сообщение</label>
                </div>

                <label class="labelFile">
                    <div class="file">
                        <div class="file__img"><img src="/public/images/prikrepitFile.png" alt=""></div>
                        <div class="file__text">Прикрепить файл</div>
                    </div>
                    <input type="file" class="fileInpt">
                </label>
                
                <button type="submit" class="goInvForm__button">Отправить</button>

            </form>
        </div>
    </div>
    <!--********************* End PopUp form *********************-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('uniquepage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>