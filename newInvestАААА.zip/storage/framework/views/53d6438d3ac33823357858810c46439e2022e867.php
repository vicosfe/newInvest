<?php $__env->startSection('content'); ?>
<!--  -->
<section style="height: calc(100% - 70px);margin-left: 105px;margin-top: 70px;">
	<?php echo $__env->make('admin.notificationTopPanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<?php echo $__env->make('admin.popUpDeleteNotifications', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<section>
		<div class="addContent">
			<div class="addContent__header">
				<a href="/admin/home">
					<div class="addContent__header--arrow">
						<div class="imgArrow"></div>
					</div>
				</a>
				

			</div>
		</div>
	</section>

	<section>
		<div class="notificationblabla">
			<div class="notifications1__wrapper">
				<h3>Результаты поиска по запросу - <?php echo e($key); ?></h3>
				<form action="#" class="searchNotifications">
					<div class="searchNotifications1Form__group">      
						<input type="text" name="searchNotification"  required >
						<span class="highlight"></span>
						<span class="bar"></span>
						<label>Поиск</label>
						<i class="fa fa-search" aria-hidden="true"></i>
					</div>
				</form>
			</div>

			<div class="windowContent">
				<div class="windowContent__top">
					<ul>
						<li style="width: 100%;max-width: 285px;">ФИО</li>
						<li style="width: 100%;max-width: 400px;">Сообщение</li>
						<li style="width: 100%;max-width: 265px;">Дата</li>
					</ul>
				</div>
				<div class="windowContent__bottom">
				<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<? $data = json_decode($item->data)?>
					<div class="infoItem1" data-id="<?php echo e($item->id); ?>">
						<div class="infoItem1__left">
							<div class="infoItem1__leftFio">
								<h4>ФИО</h4>
								<?php if(isset($data->name)): ?><p><?php echo e($data->name); ?><?php if(isset($data->tel)): ?> - <?php echo e($data->tel); ?><?php endif; ?></p><?php endif; ?>
							</div>	

							<div class="infoItem1__leftEmail">
								<h4>Email</h4>
								<?php if(isset($data->from)): ?><p><?php echo e($data->from); ?></p><?php endif; ?>
							</div>				
							
							<div class="infoItem1__leftCompany">
								<h4>Компания</h4>
								<?php if(isset($data->name)): ?><p><?php echo e($data->company); ?></p><?php endif; ?>
							</div>
							
						</div>
						<div class="infoItem1__center">
							<h4>Сообщение</h4>
							<?php if(isset($data->text)): ?><p><?php echo e($data->text); ?></p><?php endif; ?>
							</div>
							<div class="infoItem1__right">
								<h4>Дата</h4>
								<p><?php echo e($item->created_at); ?></p>
							</div>
							
							<div class="infoItem1Delete1" data-id="<?php echo e($item->id); ?>"><a href="#" ><span>x</span></a></div>
						</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



					</div>
				</div>


			</div>



		</section>





		<!--  -->
		<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminWrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>