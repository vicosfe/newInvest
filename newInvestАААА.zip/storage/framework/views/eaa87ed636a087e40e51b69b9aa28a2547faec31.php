<div class="bigSlider">
  <div class="bigSlider__carousel">
    <div class="owl-carousel-header owl-theme">
<?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if(strlen($slide->content)): ?>
        <?php echo $slide->content; ?>

        <?php else: ?>
      <div class="itemCarousel">
        <div class="itemCarousel__wrapper" style="background-image: url(<?php echo e($slide->img); ?>);">
          <div class="itemCarousel__wrapper--text centerBlock">
            <h3>
             <?php echo e($slide->title); ?>

            </h3>
          </div>
        </div>
      </div>
        <?php endif; ?>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
</div>
</div>

