<?php $__env->startSection('content'); ?>
<!--  -->
<section style="height: calc(100% - 70px);margin-left: 105px;margin-top: 70px;">
	<?php echo $__env->make('admin.editTopPanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<section>
		<div class="addContent">
			<div class="addContent__header">
				<a href="/admin/home">
					<div class="addContent__header--arrow">
						<div class="imgArrow"></div>
					</div>
				</a>
				
				<ul>
					<li><a href="/admin/change/news">Редактирование новостей</a></li>

					<li><a href="/admin/change/projects">Редактирование проекта</a></li>
					<li class="activeItem"><a href="/admin/change/articles">Редактирование статей</a></li>
					<li><a href="/admin/change/pages">Редактирование уникальных страниц</a></li>
				</ul>
			</div>
		</div>
	</section>

	<section>
		<div class="changeArticles">
			
			<?php echo $__env->make('admin.changeArticlesSearch', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



		</div>


	</section>






	<!--  -->
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.adminWrap', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>